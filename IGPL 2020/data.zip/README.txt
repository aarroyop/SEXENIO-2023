AUTOR Comunidad de Madrid
T�TULO Datos de contaminaci�n en la CAM
FECHA DE EMBARGO (si procede)
ENTIDAD FINANCIADORA Y PROYECTO DE INVESTIGACI�N (si procede)
TIPO DE DOCUMENTO Ficheros de texto con informaci�n alfanum�rica
LICENCIA DE USO Sin licencia
COBERTURA TEMPORAL DE LOS DATOS 2015-2018	
COBERTURA ESPACIAL DE LOS DATOS Comunidad Aut�noma de Madrid