AUTOR Sotavento Galicia Foundation
T�TULO Radiaci�n en panel solar en Sotavento
FECHA DE EMBARGO 18/01/2024
FIN FECHA DE EMBARGO Sin fecha fin
ENTIDAD FINANCIADORA Y PROYECTO DE INVESTIGACI�N (si procede)
TIPO DE DOCUMENTO Ficheros de texto con informaci�n alfanum�rica
LICENCIA DE USO Sin licencia
COBERTURA TEMPORAL DE LOS DATOS 2010/2011	
COBERTURA ESPACIAL DE LOS DATOS Sotavento (Galicia)

