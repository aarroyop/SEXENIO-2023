AUTOR Agencia Espa�ola de Meteorolog�a
T�TULO Contaminaci�n en CYL
FECHA DE EMBARGO (si procede)
ENTIDAD FINANCIADORA Y PROYECTO DE INVESTIGACI�N (si procede)
TIPO DE DOCUMENTO Ficheros de texto con informaci�n alfanum�rica
LICENCIA DE USO Sin licencia
COBERTURA TEMPORAL DE LOS DATOS 2000-2008	
COBERTURA ESPACIAL DE LOS DATOS Castilla y Le�n
