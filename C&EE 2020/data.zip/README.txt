AUTOR University of Bielefeld
T�TULO Anomal�as en el funcionamiento de las partes de un robot
FECHA DE EMBARGO (si procede)
ENTIDAD FINANCIADORA Y PROYECTO DE INVESTIGACI�N (si procede)
TIPO DE DOCUMENTO Ficheros .CSV con informaci�n alfanum�rica
LICENCIA DE USO Sin licencia
COBERTURA TEMPORAL DE LOS DATOS 2016	
COBERTURA ESPACIAL DE LOS DATOS 
