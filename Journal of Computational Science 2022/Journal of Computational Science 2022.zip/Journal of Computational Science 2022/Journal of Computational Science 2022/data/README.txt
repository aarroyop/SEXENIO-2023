T�TULO Datos de cultivos de patatas en Cavia (BURGOS)
AUTORES
Mercedes Yartu 
Carlos Cambra ccbaseca@ubu.es �rea: Ciencia de la Computaci�n e Inteligencia Artificial ORCID: 0000-0001-5567-9194
Milagros Navarro minago@ubu.es �rea: Edafolog�a y Qu�mica Agr�cola ORCID: 0000-0001-7012-1332
Carlos Rad crad@ubu.es �rea: Edafolog�a y Qu�mica Agr�cola ORCID: 0000-0003-2538-2212
Angel Arroyo aarroyop@ubu.es �rea: Ciencia de la Computaci�n e Inteligencia Artificial ORCID:0000-0002-1614-9075
Alvaro Herrero ahcosio@ubu.es �rea: Ciencia de la Computaci�n e Inteligencia Artificial ORCID 0000-0002-2444-5384
EDITORIAL Universidad de Burgos
DOI https://doi.org/10.1016/J.JOCS.2021.101547
FECHA PUBLICACION 2022-03-01
RESUMEN The dataset contains all interpolation data of the work "Humidity Forecasting in a Potato Plantation using Time-Series Neural Models"
PALABRAS CLAVE Precision Irrigation, Potato Crop, Time Series Forecast, Supervised learning, Neural Networks, Interpolation
MATERIA Artificial Intelligence, Inteligencia Artificial
TIPO DE DOCUMENTO Ficheros de texto con informaci�n alfanum�rica
LICENCIA DE USO Creative Commons
